# analyzer.connascence_analyzer module
