
from analyzer.core import ConnascenceViolation

class GodObjectsFixer:
    """Fixer for god objects."""
    def __init__(self):
        pass
        
    def fix(self, violation):
        return violation
