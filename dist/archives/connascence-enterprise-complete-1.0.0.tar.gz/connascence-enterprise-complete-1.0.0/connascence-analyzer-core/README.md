# Connascence-Analyzer-Core

Core Connascence Analysis Engine

## Installation

```bash
pip install connascence-analyzer-core
```

## Enterprise Support

For enterprise licensing and support, contact: sales@connascence.com

## Version

1.0.0 (Build 20250903)
