"""
Source module for connascence analyzer CLI support.
"""